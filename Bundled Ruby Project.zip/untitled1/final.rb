require 'sinatra'
require 'mysql2'


# Column 13 of DB is auto incremented id (not used).

client = Mysql2::Client.new(:host => "localhost", :username => "root", :password => "r1sdk", :database => "ruby")

x = "Paul"

results = client.query("select * from name_data where name = '#{x}'", :as => :array)

# puts(results)


# results = client.query("SELECT * FROM name_data", :as => :array)
#
# puts(results)
#
results.each do |row|
  print(row[0], row[1], (row[2]), row[3], row[4], row[5], row[6], row[7], row[8], row[9], row[10], row[11])
end

get '/' do
  redirect '/index.html'

end

# For the Ajax request
get '/name' do

  name = params["name"]

  if name == "steve"
    list = [1,2,3,4,5,6]

  else
    list = [10,9,8,7,6,5]
    #TODO: query database with name and return result (May have to be a JSON file or other format)
    end
end