require 'sinatra'
require 'mysql2'
require 'json'

# Column 13 of DB is auto incremented id (not used).
client = Mysql2::Client.new(:host => "localhost", :username => "root", :password => "r1sdk", :database => "ruby")

get '/' do
  # redirect '/index.html'
  erb :index
end

# For the Ajax request
get '/namesurf' do
  if params['name']
    name_in_db = params['name']

    # Search the DB
    results = client.query("select * from name_data where name = '#{name_in_db}'", :as => :array)

    # This prints the values for the graph to the ruby terminal for right now.
    results.each do |row|
      print(row[0], row[1], (row[2]), row[3], row[4], row[5], row[6], row[7], row[8], row[9], row[10], row[11])
    end

    # This is for displaying information on the page like his example.
    content_type :json
    { :found_data => params["name"] }.to_json


  else
    halt(404)
  end
end