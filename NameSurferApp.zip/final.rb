require 'sinatra'
require 'mysql2'
require 'json'

# Column 13 of DB is auto incremented id (not used).
client = Mysql2::Client.new(:host => "localhost", :username => "root", :password => "r1sdk", :database => "ruby")

get '/' do
  erb :index
end

# For the Ajax request
get '/namesurf' do
  if params['name']
    name_in_db = params['name']

    # Search the DB
    @results = client.query("select * from name_data where name = '#{name_in_db}'", :as => :array)

    @results.each do |row|
      @name_from_db = row
    end

    # Send the results from the database search to the chart.
    if @results.count != 0
      content_type :json
      { :found_data => @name_from_db }.to_json
    end

    else
      halt(404)
    end
end